﻿using System;
using System.Collections.Generic;

namespace CSharp.Exercises;

public static class BracketExpression
{
    /**
     * Should return true when the bracket expression passed as a string is balanced.
     * Valid bracket pairs are (), {}, and [].
     *
     * For example:
     *   "()" should return true
     *   "(" should return false
     *   "({})" should return true
     *   "({}[])" should return true
     *   "(}" should return false
     *   "([)]" should return false
     */
    public static bool IsBalanced(string expression)
    {
        var bracketPairs = new Dictionary<char, char>
    {
        { ')', '(' },
        { '}', '{' },
        { ']', '[' }
    };

        Stack<char> stack = new Stack<char>();

        foreach (char ch in expression)
        {
            if (bracketPairs.ContainsValue(ch))
            {
                stack.Push(ch);
            }
            else if (bracketPairs.ContainsKey(ch))
            {
                if (stack.Count == 0 || stack.Pop() != bracketPairs[ch])
                    return false;
            }
        }

        return stack.Count == 0;
    }
}