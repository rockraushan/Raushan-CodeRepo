﻿using System;

namespace CSharp.Exercises;

public static class Palindromes
{
    /**
     * Should return true if a given string is a palindrome, and false otherwise. A string is a palindrome if it reads
     * the same forwards as it does backwards.
     *
     * For example:
     *   "a" should return true
     *   "abba" should return true
     *   "ab" should return false
     */
    public static bool IsPalindromic(string word)
    {
        if (string.IsNullOrEmpty(word))
            return true;

        for (int i = 0; i < word.Length / 2; i++)
        {
            if (word[i] != word[word.Length - 1 - i])
                return false;
        }

        return true;
    }
}