﻿using System;

namespace CSharp.Exercises;

public static class NextBiggestNumberWithSameDigits
{
    /**
     * Should return the next biggest number with the same digits if there is such a number.
     * Otherwise, it should return -1.
     * Note that the input can be considered to be a positive integer
     *
     * For example:
     *   12 should return 21
     *   21 should return -1
     *   315 should return 351
     */
    public static int NextBiggestNumber(int n)
    {
        // If number is zero or negative, there's no valid "next bigger"
        if (n <= 0)
            return -1;

        // Convert the number to a character array (each digit becomes a char)
        char[] digits = n.ToString().ToCharArray();

        // Step 1: Find the first digit from right that is smaller than the digit next to it
        // We go from right to left, starting at second last digit
        int i = digits.Length - 2;

        // Keep moving left until we find such a digit
        while (i >= 0 && digits[i] >= digits[i + 1])
        {
            i--;
        }

        // If no such digit found, the number is the biggest possible (like 54321)
        if (i < 0)
            return -1;

        // Step 2: Find the smallest digit on right of 'i' that is greater than digits[i]
        int j = digits.Length - 1;
        while (digits[j] <= digits[i])
        {
            j--;
        }

        // Step 3: Swap the two digits
        (digits[i], digits[j]) = (digits[j], digits[i]);

        // Step 4: Reverse the digits after index i
        // This gives the smallest possible number greater than the original
        Array.Reverse(digits, i + 1, digits.Length - (i + 1));

        // Step 5: Convert the digits back to a number
        var resultStr = new string(digits);

        // Check if the result fits within int range
        if (long.TryParse(resultStr, out long result) && result <= int.MaxValue)
        {
            return (int)result;
        }

        // If not, return -1
        return -1;
    }
}