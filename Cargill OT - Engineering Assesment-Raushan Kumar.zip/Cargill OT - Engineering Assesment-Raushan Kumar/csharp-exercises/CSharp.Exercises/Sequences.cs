﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CSharp.Exercises;

public static class Sequences
{
    /**
     * Generate the sequence 0 to 9.
     */
    public static IEnumerable<int> GetNumberSequence()
    {
        var list = new List<int>();
        for (int i = 0; i <= 9; i++)
        {
            list.Add(i);
        }
        return list;
    }

    /**
     * Generate the sequence A to F.
     */
    public static IEnumerable<char> GetCharSequence()
    {
        var list = new List<char>();
        for (char c = 'A'; c <= 'F'; c++)
        {
            list.Add(c);
        }
        return list;
    }

    /**
     * Create a sequence of all combinations of the above two sequences,
     * i.e. A0, A1, A2, ..., A9, B0, B1, ..., F8, F9'.
     */
    public static IEnumerable<string> GetCombinedSequence1()
    {
        var numberSequence = GetNumberSequence();
        var charSequence = GetCharSequence();

        var result = new List<string>();

        foreach (var c in charSequence)
        {
            foreach (var n in numberSequence)
            {
                result.Add($"{c}{n}");
            }
        }

        return result;
    }

    /**
     * Combine the first two sequences to produce the new sequence A0, B1, C2, D3, E4, F5
     */
    public static IEnumerable<string> GetCombinedSequence2()
    {
        var numberList = GetNumberSequence().ToList();
        var charList = GetCharSequence().ToList();
        var result = new List<string>();

        for (int i = 0; i < charList.Count; i++)
        {
            result.Add($"{charList[i]}{numberList[i]}");
        }

        return result;
    }
}