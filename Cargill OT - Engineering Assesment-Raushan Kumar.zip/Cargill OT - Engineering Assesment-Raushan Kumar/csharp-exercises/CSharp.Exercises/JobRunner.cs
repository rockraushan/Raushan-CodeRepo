﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace CSharp.Exercises;

// Define the JobRunner class
public class JobRunner
{
    // Store the list of jobs (actions) that we want to run
    private readonly List<Action> _jobs;

    // Variable to keep track of how many jobs are finished, safely shared between threads
    private int _jobsCompleted;

    // Constructor: accepts a list of jobs and stores it as a List
    public JobRunner(IEnumerable<Action> jobs)
    {
        _jobs = jobs.ToList();
    }

    // Public read-only property to check how many jobs are completed
    public int JobsCompleted => _jobsCompleted;

    // Method to start running all jobs
    public void Run()
    {
        // Loop through each job in the list
        foreach (var job in _jobs)
        {
            // Start each job in the ThreadPool so it runs in the background
            ThreadPool.QueueUserWorkItem(_ =>
            {
                // Run the actual job (which is just a method/action)
                job();

                // Safely increase the count of completed jobs (even if multiple threads are updating)
                Interlocked.Increment(ref _jobsCompleted);

                // Print how many jobs are done so far
                Console.WriteLine($"Completed {JobsCompleted} of {_jobs.Count} jobs");
            });
        }

        // Wait here until all jobs are finished (busy wait with a small sleep to reduce CPU usage)
        while (JobsCompleted < _jobs.Count)
        {
            Thread.Sleep(10); // Sleep for 10 milliseconds to avoid 100% CPU usage
        }
    }
}
