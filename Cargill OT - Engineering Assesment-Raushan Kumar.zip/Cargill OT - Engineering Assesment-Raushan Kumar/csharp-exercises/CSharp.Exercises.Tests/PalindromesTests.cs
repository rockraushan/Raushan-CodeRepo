﻿using NUnit.Framework;

namespace CSharp.Exercises.Tests;

[TestFixture]
public class PalindromesTests
{
    [Test]
    public void ShouldReturnWhetherOrNotAStringIsAPalindrome()
    {
        Assert.That(Palindromes.IsPalindromic("a"), Is.True);
        Assert.That(Palindromes.IsPalindromic("abba"), Is.True);
        Assert.That(Palindromes.IsPalindromic("ab"), Is.False);
        Assert.That(Palindromes.IsPalindromic("aaabbaa"), Is.False);
        Assert.That(Palindromes.IsPalindromic("aba"), Is.True);
        Assert.That(Palindromes.IsPalindromic(""), Is.True);
    }
}