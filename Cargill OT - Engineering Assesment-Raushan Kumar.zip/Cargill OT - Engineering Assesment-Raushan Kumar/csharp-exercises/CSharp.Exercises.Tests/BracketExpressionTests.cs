﻿using NUnit.Framework;

namespace CSharp.Exercises.Tests;

[TestFixture]
public class BracketExpressionTests
{
    [Test]
    public void ShouldReturnWhetherOrNotTheBracketExpressionIsValid()
    {
        Assert.That(BracketExpression.IsBalanced("()"), Is.True);
        Assert.That(BracketExpression.IsBalanced("("), Is.False);
        Assert.That(BracketExpression.IsBalanced("([])"), Is.True);
        Assert.That(BracketExpression.IsBalanced("([{}]{})[]"), Is.True);
        Assert.That(BracketExpression.IsBalanced("([{}{})[]"), Is.False);
        Assert.That(BracketExpression.IsBalanced("([)]"), Is.False);
        Assert.That(BracketExpression.IsBalanced(")"), Is.False);
        Assert.That(BracketExpression.IsBalanced(""), Is.True);
    }
}