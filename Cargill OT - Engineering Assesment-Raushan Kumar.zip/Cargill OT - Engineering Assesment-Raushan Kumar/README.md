# Ocean Transportation Technical Assessment.


## Details:

The main purpose of this assessment is to get all tests within the solution to pass.

Instructions on the details themselves can be found in each class where method implementation needs to be completed. 

Good luck!!


